import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, Animated, Dimensions, StatusBar, Alert,
  Modal, FlatList, Switch, KeyboardAvoidingView, Platform,
} from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import * as Location from 'expo-location';

const { width, height } = Dimensions.get('window');

// ─── PALETTE ───────────────────────────────────────────────────────────────
const C = {
  bg:        '#07111A',
  surface:   '#0F1E2A',
  card:      '#152534',
  border:    '#1E3348',
  gold:      '#F5C518',
  goldDim:   '#C49A14',
  red:       '#E8394A',
  green:     '#1DB954',
  blue:      '#3B82F6',
  white:     '#F0F4F8',
  muted:     '#7A92A8',
  dim:       '#3A5068',
  overlay:   'rgba(7,17,26,0.92)',
};

// ─── DATA ──────────────────────────────────────────────────────────────────
const DESTINATIONS = [
  { name: 'Stabroek Market',           coord: { latitude: 6.8075, longitude: -58.1553 }, zone: 'Central Georgetown' },
  { name: "Cheddi Jagan Int'l Airport", coord: { latitude: 6.4983, longitude: -58.2541 }, zone: 'Timehri' },
  { name: 'Giftland Mall',              coord: { latitude: 6.8125, longitude: -58.1400 }, zone: 'Ruimveldt' },
  { name: 'Providence Stadium',         coord: { latitude: 6.7800, longitude: -58.1700 }, zone: 'Providence' },
  { name: 'Diamond Housing Scheme',     coord: { latitude: 6.7500, longitude: -58.1800 }, zone: 'East Bank' },
  { name: 'Bourda Market',              coord: { latitude: 6.8100, longitude: -58.1500 }, zone: 'Central Georgetown' },
  { name: 'Camp Street',                coord: { latitude: 6.8150, longitude: -58.1450 }, zone: 'Georgetown' },
  { name: 'Liliendaal',                 coord: { latitude: 6.8200, longitude: -58.1200 }, zone: 'East Coast' },
  { name: 'Berbice Bridge',             coord: { latitude: 6.3700, longitude: -57.8900 }, zone: 'Berbice' },
  { name: 'Parika Ferry Stelling',      coord: { latitude: 6.8300, longitude: -58.4200 }, zone: 'West Demerara' },
];

const RIDE_TYPES = [
  { id: 'hire',   name: 'TapX',        desc: 'Private hire car',       eta: '4 min',  price: 1800, icon: '🚗', surge: 1.0  },
  { id: 'luxury', name: 'TapLux',      desc: 'Premium executive car',  eta: '8 min',  price: 4500, icon: '🚙', surge: 1.0  },
  { id: 'route',  name: 'Route Taxi',  desc: 'Shared minibus #44',     eta: '7 min',  price: 300,  icon: '🚌', surge: 1.0  },
  { id: 'moto',   name: 'TapMoto',     desc: 'Motorcycle – beat traffic', eta: '3 min', price: 900, icon: '🏍️', surge: 1.2 },
  { id: 'parcel', name: 'TapSend',     desc: 'Same-day courier',       eta: '6 min',  price: 1000, icon: '📦', surge: 1.0  },
];

const DRIVERS = {
  hire:   { name: 'Andrew P.',         vehicle: 'Toyota Allion',    plate: 'PJJ 4471', rating: 4.9, trips: 1240 },
  luxury: { name: 'Carlton H.',        vehicle: 'Toyota Prado',     plate: 'HGG 8810', rating: 4.97,trips: 890  },
  route:  { name: 'Marcus B.',         vehicle: 'Toyota Hiace',     plate: 'BJJ 2290', rating: 4.7, trips: 3200 },
  moto:   { name: 'Ravi S.',           vehicle: 'Honda CB150',      plate: 'MCC 1192', rating: 4.85,trips: 560  },
  parcel: { name: 'Devika S.',         vehicle: 'Honda Fit',        plate: 'PGG 5512', rating: 4.95,trips: 740  },
};

const CHAT_PRESETS = [
  "I'm on my way 👍", "Almost there!", "I'm outside", "Traffic is heavy, 2 more mins",
  "Please call me", "At the entrance", "Waiting for you",
];

const RIDE_HISTORY = [
  { id: 'r1', date: 'Jun 18, 2026', from: 'Home', to: 'Stabroek Market',  type: 'TapX',   price: 1800, status: 'Completed' },
  { id: 'r2', date: 'Jun 17, 2026', from: 'Camp Street', to: 'Giftland Mall', type: 'TapLux', price: 4500, status: 'Completed' },
  { id: 'r3', date: 'Jun 15, 2026', from: 'Diamond', to: 'Bourda Market',  type: 'Route Taxi', price: 300, status: 'Completed' },
  { id: 'r4', date: 'Jun 12, 2026', from: 'Home', to: 'Airport',           type: 'TapX',   price: 3200, status: 'Cancelled'  },
];

const NOTIFICATIONS = [
  { id: 'n1', icon: '🎉', text: 'Your first ride is 20% off! Use code: TAP20', time: '2h ago',  unread: true },
  { id: 'n2', icon: '⭐', text: 'Andrew P. rated you 5 stars – great passenger!', time: '1d ago', unread: true },
  { id: 'n3', icon: '📦', text: 'Your parcel was delivered to Liliendaal.', time: '2d ago', unread: false },
  { id: 'n4', icon: '💰', text: 'Wallet topped up: G$5,000', time: '3d ago', unread: false },
];

// ─── HELPERS ───────────────────────────────────────────────────────────────
const fmtGYD = n => 'G$' + Math.round(n).toLocaleString('en-US');
const initials = name => name.split(' ').map(n => n[0]).join('').slice(0, 2);

// ─── SUB-COMPONENTS ────────────────────────────────────────────────────────
function StarRow({ value, onChange, size = 36 }) {
  return (
    <View style={{ flexDirection: 'row', gap: 12, justifyContent: 'center' }}>
      {[1,2,3,4,5].map(n => (
        <TouchableOpacity key={n} onPress={() => onChange(n)}>
          <Text style={{ fontSize: size, opacity: n <= value ? 1 : 0.25 }}>⭐</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

function Pill({ label, color = C.gold, bg }) {
  return (
    <View style={{ backgroundColor: bg || color + '22', paddingHorizontal: 10, paddingVertical: 3, borderRadius: 99 }}>
      <Text style={{ color, fontSize: 11, fontWeight: '700' }}>{label}</Text>
    </View>
  );
}

function Divider() {
  return <View style={{ height: 1, backgroundColor: C.border, marginVertical: 8 }} />;
}

function Avatar({ name, size = 48, color = C.gold }) {
  return (
    <View style={{ width: size, height: size, borderRadius: size, backgroundColor: color + '33', borderWidth: 2, borderColor: color, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ color, fontSize: size * 0.35, fontWeight: '800' }}>{initials(name)}</Text>
    </View>
  );
}

// ─── SCREENS ───────────────────────────────────────────────────────────────

// ONBOARDING / LOGIN
function OnboardingScreen({ onFinish }) {
  const [step, setStep] = useState('welcome'); // welcome | register | verify-id | verify-tin | done
  const [form, setForm] = useState({ name: '', phone: '', pin: '', idType: 'National ID', idNumber: '', tin: '' });
  const [idVerified, setIdVerified] = useState(false);
  const [tinVerified, setTinVerified] = useState(false);
  const [loading, setLoading] = useState(false);
  const fadeAnim = useRef(new Animated.Value(1)).current;

  const fade = (cb) => {
    Animated.timing(fadeAnim, { toValue: 0, duration: 200, useNativeDriver: true }).start(() => {
      cb();
      Animated.timing(fadeAnim, { toValue: 1, duration: 300, useNativeDriver: true }).start();
    });
  };

  const verifyID = () => {
    if (!form.idNumber || form.idNumber.length < 6) {
      Alert.alert('Invalid', 'Please enter a valid ID number'); return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setIdVerified(true);
      Alert.alert('✅ ID Verified', `Your ${form.idType} has been verified successfully.`);
    }, 2000);
  };

  const verifyTIN = () => {
    const tinPattern = /^\d{9,12}$/;
    if (!tinPattern.test(form.tin.replace(/[-\s]/g, ''))) {
      Alert.alert('Invalid TIN', 'Guyana TIN must be 9–12 digits. Example: 123456789'); return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setTinVerified(true);
      Alert.alert('✅ TIN Verified', 'Your Guyana Revenue Authority TIN has been verified.');
    }, 2000);
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: C.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled">
        <Animated.View style={{ flex: 1, opacity: fadeAnim }}>

          {step === 'welcome' && (
            <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32, minHeight: height }}>
              <View style={{ alignItems: 'center', marginBottom: 60 }}>
                <View style={{ width: 88, height: 88, borderRadius: 28, backgroundColor: C.gold, alignItems: 'center', justifyContent: 'center', marginBottom: 20 }}>
                  <Text style={{ fontSize: 44, fontWeight: '900', color: C.bg }}>T</Text>
                </View>
                <Text style={{ fontSize: 40, fontWeight: '900', color: C.white, letterSpacing: -1 }}>TapApp</Text>
                <Text style={{ color: C.muted, fontSize: 16, marginTop: 8, textAlign: 'center' }}>Guyana's fastest ride — tap once, arrive safe</Text>
              </View>
              <TouchableOpacity style={S.primaryBtn} onPress={() => fade(() => setStep('register'))}>
                <Text style={S.primaryBtnText}>Get Started</Text>
              </TouchableOpacity>
              <Text style={{ color: C.muted, marginTop: 20, fontSize: 13 }}>
                Already have an account?{' '}
                <Text style={{ color: C.gold }} onPress={() => fade(() => setStep('register'))}>Sign in</Text>
              </Text>
            </View>
          )}

          {step === 'register' && (
            <View style={{ padding: 24, paddingTop: 60 }}>
              <Text style={S.screenTitle}>Create Account</Text>
              <Text style={{ color: C.muted, marginBottom: 28 }}>Register to start riding</Text>

              {[
                { label: 'Full Name', key: 'name', placeholder: 'John Smith', keyboardType: 'default' },
                { label: 'Phone Number', key: 'phone', placeholder: '+592 600 0000', keyboardType: 'phone-pad' },
                { label: 'Create 4-digit PIN', key: 'pin', placeholder: '····', keyboardType: 'number-pad', secure: true, max: 4 },
              ].map(f => (
                <View key={f.key} style={{ marginBottom: 16 }}>
                  <Text style={S.label}>{f.label}</Text>
                  <TextInput
                    style={S.input}
                    value={form[f.key]}
                    onChangeText={v => setForm(p => ({ ...p, [f.key]: v }))}
                    placeholder={f.placeholder}
                    placeholderTextColor={C.dim}
                    keyboardType={f.keyboardType}
                    secureTextEntry={f.secure}
                    maxLength={f.max}
                  />
                </View>
              ))}

              <TouchableOpacity
                style={[S.primaryBtn, { marginTop: 12 }]}
                onPress={() => {
                  if (!form.name || !form.phone || form.pin.length < 4) {
                    Alert.alert('Missing info', 'Please fill all fields'); return;
                  }
                  fade(() => setStep('verify-id'));
                }}
              >
                <Text style={S.primaryBtnText}>Continue →</Text>
              </TouchableOpacity>
            </View>
          )}

          {step === 'verify-id' && (
            <View style={{ padding: 24, paddingTop: 60 }}>
              <TouchableOpacity onPress={() => fade(() => setStep('register'))} style={{ marginBottom: 20 }}>
                <Text style={{ color: C.gold, fontSize: 15 }}>← Back</Text>
              </TouchableOpacity>
              <Text style={S.screenTitle}>ID Verification</Text>
              <Text style={{ color: C.muted, marginBottom: 28 }}>Required by Guyana law for transport operators</Text>

              <View style={S.verifyBadge}>
                <Text style={{ fontSize: 28 }}>🪪</Text>
                <View style={{ flex: 1, marginLeft: 12 }}>
                  <Text style={{ color: C.white, fontWeight: '700' }}>Government-Issued ID</Text>
                  <Text style={{ color: C.muted, fontSize: 12 }}>National ID, Passport, or Driver's Licence</Text>
                </View>
                {idVerified && <Text style={{ color: C.green, fontSize: 20 }}>✓</Text>}
              </View>

              <Text style={S.label}>ID Type</Text>
              <View style={{ flexDirection: 'row', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
                {['National ID', 'Passport', "Driver's Licence"].map(t => (
                  <TouchableOpacity
                    key={t}
                    style={[S.chipBtn, form.idType === t && { borderColor: C.gold, backgroundColor: C.gold + '22' }]}
                    onPress={() => setForm(p => ({ ...p, idType: t }))}
                  >
                    <Text style={{ color: form.idType === t ? C.gold : C.muted, fontSize: 13 }}>{t}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={S.label}>ID Number</Text>
              <TextInput
                style={S.input}
                value={form.idNumber}
                onChangeText={v => setForm(p => ({ ...p, idNumber: v }))}
                placeholder="Enter your ID number"
                placeholderTextColor={C.dim}
              />

              <TouchableOpacity
                style={[S.primaryBtn, { marginTop: 12, opacity: idVerified ? 0.5 : 1 }]}
                onPress={verifyID}
                disabled={idVerified || loading}
              >
                <Text style={S.primaryBtnText}>{loading ? 'Verifying...' : idVerified ? '✓ Verified' : 'Verify ID'}</Text>
              </TouchableOpacity>

              {idVerified && (
                <TouchableOpacity style={[S.primaryBtn, { marginTop: 12, backgroundColor: C.surface, borderWidth: 1, borderColor: C.gold }]} onPress={() => fade(() => setStep('verify-tin'))}>
                  <Text style={[S.primaryBtnText, { color: C.gold }]}>Continue to TIN →</Text>
                </TouchableOpacity>
              )}
            </View>
          )}

          {step === 'verify-tin' && (
            <View style={{ padding: 24, paddingTop: 60 }}>
              <TouchableOpacity onPress={() => fade(() => setStep('verify-id'))} style={{ marginBottom: 20 }}>
                <Text style={{ color: C.gold, fontSize: 15 }}>← Back</Text>
              </TouchableOpacity>
              <Text style={S.screenTitle}>TIN Verification</Text>
              <Text style={{ color: C.muted, marginBottom: 28 }}>Guyana Revenue Authority Tax Identification Number</Text>

              <View style={S.verifyBadge}>
                <Text style={{ fontSize: 28 }}>🏛️</Text>
                <View style={{ flex: 1, marginLeft: 12 }}>
                  <Text style={{ color: C.white, fontWeight: '700' }}>GRA Tax ID Number</Text>
                  <Text style={{ color: C.muted, fontSize: 12 }}>Issued by Guyana Revenue Authority</Text>
                </View>
                {tinVerified && <Text style={{ color: C.green, fontSize: 20 }}>✓</Text>}
              </View>

              <Text style={S.label}>GRA TIN Number</Text>
              <TextInput
                style={S.input}
                value={form.tin}
                onChangeText={v => setForm(p => ({ ...p, tin: v }))}
                placeholder="e.g. 123456789"
                placeholderTextColor={C.dim}
                keyboardType="number-pad"
              />
              <Text style={{ color: C.muted, fontSize: 12, marginTop: 4, marginBottom: 16 }}>
                Find your TIN on any GRA correspondence or at gra.gov.gy
              </Text>

              <TouchableOpacity
                style={[S.primaryBtn, { opacity: tinVerified ? 0.5 : 1 }]}
                onPress={verifyTIN}
                disabled={tinVerified || loading}
              >
                <Text style={S.primaryBtnText}>{loading ? 'Verifying with GRA...' : tinVerified ? '✓ Verified' : 'Verify TIN'}</Text>
              </TouchableOpacity>

              {tinVerified && (
                <TouchableOpacity style={[S.primaryBtn, { marginTop: 12 }]} onPress={() => { fade(() => setStep('done')); setTimeout(onFinish, 600); }}>
                  <Text style={S.primaryBtnText}>🎉 Enter TapApp</Text>
                </TouchableOpacity>
              )}

              <TouchableOpacity style={{ marginTop: 16, alignItems: 'center' }} onPress={() => { fade(() => setStep('done')); setTimeout(onFinish, 600); }}>
                <Text style={{ color: C.muted, fontSize: 13 }}>Skip for now (required within 7 days)</Text>
              </TouchableOpacity>
            </View>
          )}

        </Animated.View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// MAIN APP
export default function TapApp() {
  const [authed, setAuthed] = useState(false);
  const [tab, setTab] = useState('home');
  const [stage, setStage] = useState('home');
  const [destination, setDestination] = useState(null);
  const [query, setQuery] = useState('');
  const [rideType, setRideType] = useState(null);
  const [payment, setPayment] = useState('Cash');
  const [rating, setRating] = useState(0);
  const [userLocation, setUserLocation] = useState(null);
  const [region, setRegion] = useState({ latitude: 6.801, longitude: -58.15, latitudeDelta: 0.07, longitudeDelta: 0.07 });
  const [walletBalance, setWalletBalance] = useState(12500);
  const [chatMessages, setChatMessages] = useState([
    { id: 1, from: 'driver', text: "On my way! 🚗" },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [showChat, setShowChat] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [promoCode, setPromoCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [notifications, setNotifications] = useState(NOTIFICATIONS);
  const [savedPlaces, setSavedPlaces] = useState([
    { label: '🏠 Home', address: 'Lot 5 New Market Street, Georgetown' },
    { label: '💼 Work', address: 'Camp Street, Georgetown' },
  ]);

  const carAnim = useRef(new Animated.Value(0)).current;
  const sheetAnim = useRef(new Animated.Value(350)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const loc = await Location.getCurrentPositionAsync({});
      setUserLocation(loc.coords);
      setRegion({ latitude: loc.coords.latitude, longitude: loc.coords.longitude, latitudeDelta: 0.05, longitudeDelta: 0.05 });
    })();
  }, []);

  useEffect(() => {
    if (stage === 'matching') {
      Animated.loop(Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.3, duration: 700, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1,   duration: 700, useNativeDriver: true }),
      ])).start();
      const t = setTimeout(() => { setStage('enroute'); pulseAnim.stopAnimation(); pulseAnim.setValue(1); }, 2500);
      return () => clearTimeout(t);
    }
    if (stage === 'enroute') {
      carAnim.setValue(0);
      Animated.timing(carAnim, { toValue: 1, duration: 3500, useNativeDriver: true }).start();
      const t = setTimeout(() => setStage('trip'), 3600);
      return () => clearTimeout(t);
    }
    if (stage === 'trip') {
      Animated.timing(carAnim, { toValue: 2, duration: 3000, useNativeDriver: true }).start();
      const t = setTimeout(() => { setStage('complete'); Animated.timing(sheetAnim, { toValue: 0, duration: 380, useNativeDriver: true }).start(); }, 3100);
      return () => clearTimeout(t);
    }
  }, [stage]);

  const pickDestination = (d) => {
    setDestination(d);
    setStage('options');
    setRegion({ ...d.coord, latitudeDelta: 0.07, longitudeDelta: 0.07 });
  };

  const callRide = () => {
    if (!rideType) return;
    if (payment === 'Wallet' && walletBalance < rideType.price) {
      Alert.alert('Insufficient Wallet', `Your wallet has ${fmtGYD(walletBalance)} but ride costs ${fmtGYD(rideType.price)}. Please top up.`); return;
    }
    setStage('matching');
    setShowChat(false);
    setChatMessages([{ id: 1, from: 'driver', text: "On my way! 🚗" }]);
  };

  const applyPromo = () => {
    if (promoCode.toUpperCase() === 'TAP20') {
      setDiscount(0.2);
      Alert.alert('🎉 Promo Applied!', '20% discount activated');
    } else {
      Alert.alert('Invalid Code', 'That promo code is not valid');
    }
  };

  const sendChat = (msg) => {
    const text = msg || chatInput.trim();
    if (!text) return;
    const newMsg = { id: Date.now(), from: 'me', text };
    setChatMessages(p => [...p, newMsg]);
    setChatInput('');
    setTimeout(() => {
      const replies = ["👍", "Ok, noted!", "Almost there!", "2 minutes away!"];
      setChatMessages(p => [...p, { id: Date.now() + 1, from: 'driver', text: replies[Math.floor(Math.random() * replies.length)] }]);
    }, 1200);
  };

  const finishTrip = () => {
    if (payment === 'Wallet') setWalletBalance(b => b - Math.round(rideType.price * (1 - discount)));
    setDestination(null); setQuery(''); setRideType(null); setRating(0);
    setDiscount(0); setPromoCode(''); setStage('home'); setShowChat(false);
    sheetAnim.setValue(350);
  };

  const unreadCount = notifications.filter(n => n.unread).length;
  const driver = rideType ? DRIVERS[rideType.id] : null;
  const filteredDests = DESTINATIONS.filter(d => d.name.toLowerCase().includes(query.toLowerCase()));
  const finalPrice = rideType ? Math.round(rideType.price * rideType.surge * (1 - discount)) : 0;

  if (!authed) return <OnboardingScreen onFinish={() => setAuthed(true)} />;

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />

      {/* ── HEADER ── */}
      <View style={S.header}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <View style={S.logoCircle}>
            <Text style={{ color: C.bg, fontSize: 22, fontWeight: '900' }}>T</Text>
          </View>
          <Text style={{ color: C.white, fontSize: 22, fontWeight: '800' }}>TapApp</Text>
        </View>
        <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          <TouchableOpacity onPress={() => setShowNotifications(true)} style={{ position: 'relative' }}>
            <Text style={{ fontSize: 22 }}>🔔</Text>
            {unreadCount > 0 && (
              <View style={S.badge}><Text style={{ color: C.white, fontSize: 10, fontWeight: '800' }}>{unreadCount}</Text></View>
            )}
          </TouchableOpacity>
          <View style={{ backgroundColor: C.card, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 99, borderWidth: 1, borderColor: C.border }}>
            <Text style={{ color: C.gold, fontWeight: '700', fontSize: 13 }}>{fmtGYD(walletBalance)}</Text>
          </View>
        </View>
      </View>

      {/* ── MAP ── */}
      {tab === 'home' && (
        <View style={S.mapWrap}>
          <MapView
            style={StyleSheet.absoluteFillObject}
            region={region}
            onRegionChangeComplete={setRegion}
            showsUserLocation
            showsMyLocationButton
          >
            {userLocation && <Marker coordinate={userLocation} title="You" pinColor={C.gold} />}
            {destination?.coord && <Marker coordinate={destination.coord} title={destination.name} pinColor={C.red} />}
            {userLocation && destination?.coord && (
              <Polyline coordinates={[userLocation, destination.coord]} strokeColor={C.gold} strokeWidth={3} lineDashPattern={[6, 4]} />
            )}
          </MapView>

          {/* Animated car */}
          {(stage === 'enroute' || stage === 'trip') && (
            <Animated.View style={[S.animCar, {
              transform: [{ translateX: carAnim.interpolate({ inputRange: [0, 1, 2], outputRange: [width * 0.1, width * 0.45, width * 0.78] }) }]
            }]}>
              <View style={S.carBubble}><Text style={{ fontSize: 24 }}>🚗</Text></View>
            </Animated.View>
          )}
        </View>
      )}

      {/* ── HOME TAB ── */}
      {tab === 'home' && stage === 'home' && (
        <ScrollView style={S.panel} contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>
          <View style={S.searchBar}>
            <Text style={{ fontSize: 18 }}>🔍</Text>
            <TextInput
              value={query}
              onChangeText={setQuery}
              placeholder="Where to?"
              style={{ flex: 1, marginLeft: 10, color: C.white, fontSize: 16 }}
              placeholderTextColor={C.muted}
            />
            {query.length > 0 && (
              <TouchableOpacity onPress={() => setQuery('')}><Text style={{ color: C.muted, fontSize: 18 }}>✕</Text></TouchableOpacity>
            )}
          </View>

          {/* Saved Places */}
          {!query && (
            <>
              <View style={{ flexDirection: 'row', gap: 10, marginBottom: 16 }}>
                {savedPlaces.map((sp, i) => (
                  <TouchableOpacity key={i} style={S.savedChip} onPress={() => pickDestination(DESTINATIONS[0])}>
                    <Text style={{ color: C.white, fontWeight: '600', fontSize: 13 }}>{sp.label}</Text>
                    <Text style={{ color: C.muted, fontSize: 11 }} numberOfLines={1}>{sp.address}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              <Text style={S.sectionLabel}>Popular Destinations</Text>
            </>
          )}

          {filteredDests.map((d, i) => (
            <TouchableOpacity key={i} style={S.destRow} onPress={() => pickDestination(d)}>
              <View style={S.destIconWrap}><Text style={{ fontSize: 20 }}>📍</Text></View>
              <View style={{ flex: 1 }}>
                <Text style={{ color: C.white, fontSize: 15, fontWeight: '600' }}>{d.name}</Text>
                <Text style={{ color: C.muted, fontSize: 12 }}>{d.zone}</Text>
              </View>
              <Text style={{ color: C.dim, fontSize: 18 }}>›</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}

      {/* ── OPTIONS ── */}
      {tab === 'home' && stage === 'options' && (
        <ScrollView style={S.panel} contentContainerStyle={{ padding: 16, paddingBottom: 120 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 18 }}>
            <TouchableOpacity style={S.backBtn} onPress={() => setStage('home')}>
              <Text style={{ color: C.gold, fontSize: 15 }}>←</Text>
            </TouchableOpacity>
            <View>
              <Text style={{ color: C.muted, fontSize: 12 }}>Going to</Text>
              <Text style={{ color: C.white, fontSize: 16, fontWeight: '700' }}>{destination?.name}</Text>
            </View>
          </View>

          {RIDE_TYPES.map((r, i) => {
            const sel = rideType?.id === r.id;
            return (
              <TouchableOpacity key={i} style={[S.rideCard, sel && { borderColor: C.gold, backgroundColor: C.gold + '11' }]} onPress={() => setRideType(r)}>
                <Text style={{ fontSize: 32, marginRight: 12 }}>{r.icon}</Text>
                <View style={{ flex: 1 }}>
                  <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
                    <Text style={{ color: C.white, fontSize: 16, fontWeight: '700' }}>{r.name}</Text>
                    {r.surge > 1 && <Pill label={`${r.surge}x surge`} color={C.red} />}
                  </View>
                  <Text style={{ color: C.muted, fontSize: 13, marginTop: 2 }}>{r.desc} · {r.eta}</Text>
                </View>
                <Text style={{ color: sel ? C.gold : C.white, fontSize: 18, fontWeight: '800' }}>{fmtGYD(Math.round(r.price * r.surge))}</Text>
              </TouchableOpacity>
            );
          })}

          {/* Promo */}
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 10, marginBottom: 10 }}>
            <TextInput
              style={[S.input, { flex: 1, marginBottom: 0 }]}
              placeholder="Promo code"
              placeholderTextColor={C.dim}
              value={promoCode}
              onChangeText={setPromoCode}
              autoCapitalize="characters"
            />
            <TouchableOpacity style={{ backgroundColor: C.gold, paddingHorizontal: 18, borderRadius: 14, justifyContent: 'center' }} onPress={applyPromo}>
              <Text style={{ color: C.bg, fontWeight: '800' }}>Apply</Text>
            </TouchableOpacity>
          </View>
          {discount > 0 && <Text style={{ color: C.green, fontSize: 13, marginBottom: 10 }}>✓ {(discount * 100).toFixed(0)}% discount applied!</Text>}

          {/* Payment */}
          <Text style={S.sectionLabel}>Payment Method</Text>
          <View style={{ flexDirection: 'row', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
            {[
              { label: '💵 Cash', key: 'Cash' },
              { label: '💳 Card', key: 'Card' },
              { label: `👛 Wallet (${fmtGYD(walletBalance)})`, key: 'Wallet' },
              { label: '📱 Mobile Money', key: 'Mobile Money' },
            ].map(p => (
              <TouchableOpacity
                key={p.key}
                style={[S.chipBtn, payment === p.key && { borderColor: C.gold, backgroundColor: C.gold + '22' }]}
                onPress={() => setPayment(p.key)}
              >
                <Text style={{ color: payment === p.key ? C.gold : C.muted, fontSize: 13 }}>{p.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {rideType && (
            <View style={S.priceSummary}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={{ color: C.muted }}>Base fare</Text>
                <Text style={{ color: C.white }}>{fmtGYD(rideType.price)}</Text>
              </View>
              {rideType.surge > 1 && (
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 }}>
                  <Text style={{ color: C.red }}>Surge ({rideType.surge}x)</Text>
                  <Text style={{ color: C.red }}>+{fmtGYD(rideType.price * (rideType.surge - 1))}</Text>
                </View>
              )}
              {discount > 0 && (
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 }}>
                  <Text style={{ color: C.green }}>Promo discount</Text>
                  <Text style={{ color: C.green }}>-{fmtGYD(rideType.price * rideType.surge * discount)}</Text>
                </View>
              )}
              <Divider />
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={{ color: C.white, fontWeight: '700', fontSize: 16 }}>Total</Text>
                <Text style={{ color: C.gold, fontWeight: '800', fontSize: 18 }}>{fmtGYD(finalPrice)}</Text>
              </View>
            </View>
          )}

          <TouchableOpacity
            style={[S.primaryBtn, !rideType && { opacity: 0.4 }]}
            onPress={callRide}
            disabled={!rideType}
          >
            <Text style={S.primaryBtnText}>👆 Tap to Call Ride</Text>
          </TouchableOpacity>
        </ScrollView>
      )}

      {/* ── MATCHING / ENROUTE / TRIP ── */}
      {tab === 'home' && (stage === 'matching' || stage === 'enroute' || stage === 'trip') && driver && (
        <View style={[S.panel, { alignItems: 'center', justifyContent: 'center', padding: 24 }]}>
          {stage === 'matching' && (
            <Animated.View style={{ transform: [{ scale: pulseAnim }], marginBottom: 20 }}>
              <View style={{ width: 90, height: 90, borderRadius: 99, backgroundColor: C.gold + '33', borderWidth: 3, borderColor: C.gold, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ fontSize: 40 }}>👆</Text>
              </View>
            </Animated.View>
          )}
          {stage !== 'matching' && (
            <Text style={{ fontSize: 60, marginBottom: 16 }}>{rideType.icon}</Text>
          )}

          <Text style={{ color: C.white, fontSize: 20, fontWeight: '700', textAlign: 'center', marginBottom: 4 }}>
            {stage === 'matching' ? 'Finding your driver...' : stage === 'enroute' ? 'Driver is on the way' : `Heading to ${destination?.name}`}
          </Text>
          <Text style={{ color: C.muted, fontSize: 14, marginBottom: 24, textAlign: 'center' }}>
            {stage === 'matching' ? 'Usually takes under 30 seconds' : stage === 'enroute' ? `ETA: ${rideType.eta}` : 'Sit back and relax'}
          </Text>

          {/* Driver Card */}
          <View style={S.driverCard}>
            <Avatar name={driver.name} size={56} />
            <View style={{ flex: 1, marginLeft: 14 }}>
              <Text style={{ color: C.white, fontSize: 17, fontWeight: '700' }}>{driver.name}</Text>
              <Text style={{ color: C.muted, fontSize: 13 }}>{driver.vehicle} · {driver.plate}</Text>
              <Text style={{ color: C.muted, fontSize: 12 }}>{driver.trips.toLocaleString()} trips</Text>
            </View>
            <View style={{ alignItems: 'flex-end', gap: 8 }}>
              <Pill label={`⭐ ${driver.rating}`} color={C.gold} />
              <TouchableOpacity style={S.iconBtn} onPress={() => setShowChat(true)}>
                <Text style={{ fontSize: 20 }}>💬</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* SOS */}
          <TouchableOpacity style={S.sosBtn} onPress={() => Alert.alert('🚨 Emergency', 'Connecting to emergency services...')}>
            <Text style={{ color: C.white, fontWeight: '800', fontSize: 13 }}>🆘 SOS</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => { setStage('home'); setDestination(null); setRideType(null); }}>
            <Text style={{ color: C.muted, marginTop: 16, fontSize: 14 }}>Cancel ride</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* ── COMPLETE ── */}
      {tab === 'home' && stage === 'complete' && (
        <Animated.View style={[S.bottomSheet, { transform: [{ translateY: sheetAnim }] }]}>
          <View style={S.sheetHandle} />
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <Text style={{ color: C.white, fontSize: 22, fontWeight: '800' }}>Trip Complete 🎉</Text>
            <TouchableOpacity onPress={finishTrip}><Text style={{ color: C.muted, fontSize: 22 }}>✕</Text></TouchableOpacity>
          </View>

          <View style={{ alignItems: 'center', marginBottom: 24, backgroundColor: C.card, padding: 20, borderRadius: 18, borderWidth: 1, borderColor: C.border }}>
            <Text style={{ color: C.muted, fontSize: 14 }}>{rideType?.name} · {destination?.name}</Text>
            <Text style={{ color: C.gold, fontSize: 52, fontWeight: '900', marginVertical: 8 }}>{fmtGYD(finalPrice)}</Text>
            <Text style={{ color: C.green, fontSize: 13 }}>Paid via {payment}</Text>
          </View>

          <Text style={{ color: C.muted, fontSize: 13, textAlign: 'center', marginBottom: 12 }}>Rate your {driver?.name}</Text>
          <StarRow value={rating} onChange={setRating} />

          <TouchableOpacity style={[S.primaryBtn, { marginTop: 24 }]} onPress={finishTrip}>
            <Text style={S.primaryBtnText}>Done</Text>
          </TouchableOpacity>
        </Animated.View>
      )}

      {/* ── WALLET TAB ── */}
      {tab === 'wallet' && (
        <ScrollView style={S.tabScreen} contentContainerStyle={{ padding: 20, paddingBottom: 100 }}>
          <Text style={S.screenTitle}>Wallet</Text>

          <View style={S.walletCard}>
            <Text style={{ color: C.gold, fontSize: 13, fontWeight: '700', letterSpacing: 1, textTransform: 'uppercase' }}>Available Balance</Text>
            <Text style={{ color: C.white, fontSize: 44, fontWeight: '900', marginVertical: 8 }}>{fmtGYD(walletBalance)}</Text>
            <Text style={{ color: C.muted, fontSize: 13 }}>Guyana Dollars (GYD)</Text>
          </View>

          <View style={{ flexDirection: 'row', gap: 10, marginBottom: 24 }}>
            {['G$2,000', 'G$5,000', 'G$10,000'].map((amt, i) => {
              const val = [2000, 5000, 10000][i];
              return (
                <TouchableOpacity
                  key={i}
                  style={[S.chipBtn, { flex: 1, alignItems: 'center', paddingVertical: 14 }]}
                  onPress={() => { setWalletBalance(b => b + val); Alert.alert('✅ Topped Up', `${amt} added to wallet`); }}
                >
                  <Text style={{ color: C.white, fontWeight: '700' }}>+ {amt}</Text>
                </TouchableOpacity>
              );
            })}
          </View>

          <Text style={S.sectionLabel}>Transaction History</Text>
          {[
            { label: 'TapX ride – Stabroek Market', date: 'Jun 18', amount: -1800, icon: '🚗' },
            { label: 'Wallet top-up',                date: 'Jun 17', amount: 5000,  icon: '💰' },
            { label: 'TapLux ride – Camp Street',    date: 'Jun 15', amount: -4500, icon: '🚙' },
            { label: 'Promo cashback TAP20',          date: 'Jun 14', amount: 360,   icon: '🎁' },
          ].map((tx, i) => (
            <View key={i} style={S.txRow}>
              <Text style={{ fontSize: 24, marginRight: 12 }}>{tx.icon}</Text>
              <View style={{ flex: 1 }}>
                <Text style={{ color: C.white, fontSize: 14, fontWeight: '600' }}>{tx.label}</Text>
                <Text style={{ color: C.muted, fontSize: 12 }}>{tx.date}</Text>
              </View>
              <Text style={{ color: tx.amount > 0 ? C.green : C.white, fontWeight: '700', fontSize: 15 }}>
                {tx.amount > 0 ? '+' : ''}{fmtGYD(tx.amount)}
              </Text>
            </View>
          ))}
        </ScrollView>
      )}

      {/* ── HISTORY TAB ── */}
      {tab === 'history' && (
        <ScrollView style={S.tabScreen} contentContainerStyle={{ padding: 20, paddingBottom: 100 }}>
          <Text style={S.screenTitle}>Ride History</Text>
          {RIDE_HISTORY.map((r, i) => (
            <View key={i} style={S.historyCard}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 }}>
                <Text style={{ color: C.muted, fontSize: 12 }}>{r.date}</Text>
                <Pill label={r.status} color={r.status === 'Completed' ? C.green : C.red} />
              </View>
              <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-start', marginBottom: 10 }}>
                <View style={{ alignItems: 'center', gap: 2 }}>
                  <View style={{ width: 10, height: 10, borderRadius: 99, backgroundColor: C.gold, borderWidth: 2, borderColor: C.goldDim }} />
                  <View style={{ width: 2, height: 24, backgroundColor: C.border }} />
                  <View style={{ width: 10, height: 10, borderRadius: 2, backgroundColor: C.red }} />
                </View>
                <View style={{ gap: 12 }}>
                  <Text style={{ color: C.white, fontWeight: '600' }}>{r.from}</Text>
                  <Text style={{ color: C.white, fontWeight: '600' }}>{r.to}</Text>
                </View>
              </View>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                <Pill label={r.type} color={C.muted} />
                <Text style={{ color: C.gold, fontSize: 16, fontWeight: '800' }}>{fmtGYD(r.price)}</Text>
              </View>
            </View>
          ))}
        </ScrollView>
      )}

      {/* ── PROFILE TAB ── */}
      {tab === 'profile' && (
        <ScrollView style={S.tabScreen} contentContainerStyle={{ padding: 20, paddingBottom: 100 }}>
          <Text style={S.screenTitle}>Profile</Text>

          <View style={{ alignItems: 'center', marginBottom: 24 }}>
            <Avatar name="John Smith" size={80} />
            <Text style={{ color: C.white, fontSize: 20, fontWeight: '800', marginTop: 12 }}>John Smith</Text>
            <Text style={{ color: C.muted, fontSize: 14 }}>+592 600 0000</Text>
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
              <Pill label="✅ ID Verified" color={C.green} />
              <Pill label="✅ TIN Verified" color={C.green} />
            </View>
          </View>

          <View style={S.profileCard}>
            {[
              { label: 'Total Rides',  value: '47',          icon: '🚗' },
              { label: 'Total Spent',  value: 'G$84,200',    icon: '💵' },
              { label: 'Avg Rating',   value: '4.9 ⭐',      icon: '👤' },
              { label: 'Member Since', value: 'Jan 2025',    icon: '📅' },
            ].map((s, i) => (
              <View key={i} style={[S.statRow, i < 3 && { borderBottomWidth: 1, borderColor: C.border }]}>
                <Text style={{ fontSize: 20 }}>{s.icon}</Text>
                <Text style={{ color: C.muted, flex: 1, marginLeft: 12 }}>{s.label}</Text>
                <Text style={{ color: C.white, fontWeight: '700' }}>{s.value}</Text>
              </View>
            ))}
          </View>

          <Text style={S.sectionLabel}>Saved Places</Text>
          {savedPlaces.map((sp, i) => (
            <View key={i} style={S.destRow}>
              <Text style={{ fontSize: 20, marginRight: 12 }}>{sp.label.split(' ')[0]}</Text>
              <View style={{ flex: 1 }}>
                <Text style={{ color: C.white, fontWeight: '600' }}>{sp.label.split(' ').slice(1).join(' ')}</Text>
                <Text style={{ color: C.muted, fontSize: 12 }}>{sp.address}</Text>
              </View>
              <Text style={{ color: C.dim }}>›</Text>
            </View>
          ))}

          <Text style={S.sectionLabel}>Security & Verification</Text>
          <View style={S.profileCard}>
            {[
              { label: 'Change PIN',        icon: '🔑' },
              { label: 'Two-Factor Auth',   icon: '🛡️' },
              { label: 'ID Documents',      icon: '🪪' },
              { label: 'GRA TIN Number',    icon: '🏛️' },
            ].map((item, i) => (
              <TouchableOpacity key={i} style={[S.statRow, i < 3 && { borderBottomWidth: 1, borderColor: C.border }]}
                onPress={() => Alert.alert(item.label, 'Feature available in next update')}>
                <Text style={{ fontSize: 20 }}>{item.icon}</Text>
                <Text style={{ color: C.white, flex: 1, marginLeft: 12 }}>{item.label}</Text>
                <Text style={{ color: C.dim }}>›</Text>
              </TouchableOpacity>
            ))}
          </View>

          <TouchableOpacity style={[S.primaryBtn, { backgroundColor: C.red + '33', borderWidth: 1, borderColor: C.red, marginTop: 8 }]}
            onPress={() => Alert.alert('Sign Out', 'Are you sure?', [
              { text: 'Cancel' }, { text: 'Sign Out', style: 'destructive', onPress: () => setAuthed(false) }
            ])}>
            <Text style={[S.primaryBtnText, { color: C.red }]}>Sign Out</Text>
          </TouchableOpacity>
        </ScrollView>
      )}

      {/* ── BOTTOM NAV ── */}
      <View style={S.bottomNav}>
        {[
          { key: 'home',    icon: '🗺️',  label: 'Ride'     },
          { key: 'wallet',  icon: '👛',  label: 'Wallet'   },
          { key: 'history', icon: '🕐',  label: 'History'  },
          { key: 'profile', icon: '👤',  label: 'Profile'  },
        ].map(t => (
          <TouchableOpacity key={t.key} style={S.navItem} onPress={() => { setTab(t.key); if (t.key === 'home' && stage !== 'home' && stage !== 'options' && stage !== 'matching' && stage !== 'enroute' && stage !== 'trip' && stage !== 'complete') setStage('home'); }}>
            <Text style={{ fontSize: 22 }}>{t.icon}</Text>
            <Text style={{ color: tab === t.key ? C.gold : C.muted, fontSize: 11, fontWeight: tab === t.key ? '700' : '400', marginTop: 2 }}>{t.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* ── CHAT MODAL ── */}
      <Modal visible={showChat} transparent animationType="slide">
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <View style={{ flex: 1, backgroundColor: C.overlay, justifyContent: 'flex-end' }}>
            <View style={{ backgroundColor: C.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: height * 0.7 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                <Text style={{ color: C.white, fontSize: 18, fontWeight: '700' }}>Chat with {driver?.name}</Text>
                <TouchableOpacity onPress={() => setShowChat(false)}><Text style={{ color: C.muted, fontSize: 22 }}>✕</Text></TouchableOpacity>
              </View>
              <ScrollView style={{ maxHeight: 220, marginBottom: 12 }}>
                {chatMessages.map(m => (
                  <View key={m.id} style={{ alignItems: m.from === 'me' ? 'flex-end' : 'flex-start', marginBottom: 8 }}>
                    <View style={{ backgroundColor: m.from === 'me' ? C.gold : C.card, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 18, maxWidth: '75%' }}>
                      <Text style={{ color: m.from === 'me' ? C.bg : C.white, fontWeight: m.from === 'me' ? '600' : '400' }}>{m.text}</Text>
                    </View>
                  </View>
                ))}
              </ScrollView>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 10 }}>
                <View style={{ flexDirection: 'row', gap: 8 }}>
                  {CHAT_PRESETS.map((p, i) => (
                    <TouchableOpacity key={i} style={S.chipBtn} onPress={() => sendChat(p)}>
                      <Text style={{ color: C.muted, fontSize: 12 }}>{p}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </ScrollView>
              <View style={{ flexDirection: 'row', gap: 10 }}>
                <TextInput
                  style={[S.input, { flex: 1, marginBottom: 0 }]}
                  value={chatInput}
                  onChangeText={setChatInput}
                  placeholder="Type a message..."
                  placeholderTextColor={C.dim}
                />
                <TouchableOpacity style={{ backgroundColor: C.gold, paddingHorizontal: 18, borderRadius: 14, justifyContent: 'center' }} onPress={() => sendChat()}>
                  <Text style={{ color: C.bg, fontWeight: '800', fontSize: 18 }}>↑</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* ── NOTIFICATIONS MODAL ── */}
      <Modal visible={showNotifications} transparent animationType="slide">
        <View style={{ flex: 1, backgroundColor: C.overlay, justifyContent: 'flex-end' }}>
          <View style={{ backgroundColor: C.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: height * 0.65 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <Text style={{ color: C.white, fontSize: 18, fontWeight: '700' }}>Notifications</Text>
              <TouchableOpacity onPress={() => { setShowNotifications(false); setNotifications(n => n.map(x => ({ ...x, unread: false }))); }}>
                <Text style={{ color: C.muted, fontSize: 22 }}>✕</Text>
              </TouchableOpacity>
            </View>
            <FlatList
              data={notifications}
              keyExtractor={n => n.id}
              renderItem={({ item }) => (
                <View style={[S.notifRow, item.unread && { backgroundColor: C.gold + '11' }]}>
                  <Text style={{ fontSize: 24, marginRight: 12 }}>{item.icon}</Text>
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: C.white, fontSize: 14 }}>{item.text}</Text>
                    <Text style={{ color: C.muted, fontSize: 12, marginTop: 2 }}>{item.time}</Text>
                  </View>
                  {item.unread && <View style={{ width: 8, height: 8, borderRadius: 99, backgroundColor: C.gold }} />}
                </View>
              )}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

// ─── STYLES ────────────────────────────────────────────────────────────────
const S = StyleSheet.create({
  header:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 52, paddingBottom: 12, backgroundColor: C.bg, zIndex: 10 },
  logoCircle:   { width: 38, height: 38, borderRadius: 12, backgroundColor: C.gold, alignItems: 'center', justifyContent: 'center' },
  badge:        { position: 'absolute', top: -4, right: -4, backgroundColor: C.red, borderRadius: 99, width: 16, height: 16, alignItems: 'center', justifyContent: 'center' },

  mapWrap:      { height: 240, marginHorizontal: 12, borderRadius: 22, overflow: 'hidden', borderWidth: 1, borderColor: C.border, position: 'relative' },
  animCar:      { position: 'absolute', top: '45%', zIndex: 20 },
  carBubble:    { backgroundColor: C.gold, paddingHorizontal: 8, paddingVertical: 6, borderRadius: 99, shadowColor: '#000', shadowOpacity: 0.4, shadowOffset: { width: 0, height: 4 }, shadowRadius: 8 },

  panel:        { flex: 1 },
  tabScreen:    { flex: 1 },
  screenTitle:  { color: C.white, fontSize: 26, fontWeight: '900', marginBottom: 6, letterSpacing: -0.5 },
  sectionLabel: { color: C.muted, fontSize: 11, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10, marginTop: 4 },

  searchBar:    { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderRadius: 16, paddingHorizontal: 16, paddingVertical: 14, borderWidth: 1, borderColor: C.border, marginBottom: 14 },
  savedChip:    { flex: 1, backgroundColor: C.card, padding: 14, borderRadius: 16, borderWidth: 1, borderColor: C.border },
  destRow:      { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, padding: 16, borderRadius: 16, marginBottom: 8, borderWidth: 1, borderColor: C.border },
  destIconWrap: { width: 40, height: 40, borderRadius: 12, backgroundColor: C.gold + '22', alignItems: 'center', justifyContent: 'center', marginRight: 12 },

  rideCard:     { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, padding: 18, borderRadius: 18, marginBottom: 10, borderWidth: 1.5, borderColor: C.border },
  priceSummary: { backgroundColor: C.card, padding: 16, borderRadius: 16, marginBottom: 16, borderWidth: 1, borderColor: C.border },
  driverCard:   { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, padding: 18, borderRadius: 20, width: '100%', marginTop: 20, borderWidth: 1, borderColor: C.border },
  sosBtn:       { marginTop: 16, backgroundColor: C.red, paddingHorizontal: 24, paddingVertical: 10, borderRadius: 99 },
  iconBtn:      { backgroundColor: C.card, padding: 8, borderRadius: 12, borderWidth: 1, borderColor: C.border },

  bottomSheet:  { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: C.surface, borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 24, paddingBottom: 40, borderTopWidth: 1, borderColor: C.border, maxHeight: '85%' },
  sheetHandle:  { width: 40, height: 4, backgroundColor: C.border, borderRadius: 99, alignSelf: 'center', marginBottom: 20 },

  bottomNav:    { flexDirection: 'row', backgroundColor: C.surface, borderTopWidth: 1, borderColor: C.border, paddingBottom: Platform.OS === 'ios' ? 28 : 12, paddingTop: 10, position: 'absolute', bottom: 0, left: 0, right: 0 },
  navItem:      { flex: 1, alignItems: 'center' },

  walletCard:   { backgroundColor: C.card, borderRadius: 22, padding: 24, marginBottom: 20, borderWidth: 1, borderColor: C.border },
  txRow:        { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, padding: 14, borderRadius: 14, marginBottom: 8, borderWidth: 1, borderColor: C.border },
  historyCard:  { backgroundColor: C.card, padding: 16, borderRadius: 18, marginBottom: 12, borderWidth: 1, borderColor: C.border },
  profileCard:  { backgroundColor: C.card, borderRadius: 18, marginBottom: 16, borderWidth: 1, borderColor: C.border, overflow: 'hidden' },
  statRow:      { flexDirection: 'row', alignItems: 'center', padding: 16 },
  notifRow:     { flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: 14, marginBottom: 8, backgroundColor: C.card, borderWidth: 1, borderColor: C.border },

  primaryBtn:   { backgroundColor: C.gold, height: 58, borderRadius: 18, alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  primaryBtnText:{ color: C.bg, fontSize: 17, fontWeight: '800' },
  backBtn:      { backgroundColor: C.card, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 12, borderWidth: 1, borderColor: C.border },

  input:        { backgroundColor: C.card, borderRadius: 14, padding: 14, color: C.white, fontSize: 15, borderWidth: 1, borderColor: C.border, marginBottom: 4 },
  label:        { color: C.muted, fontSize: 13, fontWeight: '600', marginBottom: 6, marginTop: 8 },
  chipBtn:      { paddingHorizontal: 14, paddingVertical: 10, borderRadius: 12, borderWidth: 1, borderColor: C.border, backgroundColor: C.card },
  verifyBadge:  { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderRadius: 16, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: C.border },
});
